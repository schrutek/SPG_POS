﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace LinqToXML_Step2
{
    class Program
    {
        static void Main()
        {
            // Pfad zum XML File über Refection ermitteln.
            // Die XML Datei muss im gleichen Verzeichnis wie die exe liegen
            var pathXmlFile = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), "Adressen.xml");

            // XML File laden
            var adressen = XElement.Load(pathXmlFile);

            // Ausgabe aller Namen in einer Schleife:
            Console.WriteLine("Ausgabe aller Namen in einer Schleife:");

            foreach (var a in adressen.Elements())
                Console.WriteLine(a.Element("Name").Value);

            // Ausgabe aller Postleitzahlen:
            Console.WriteLine(Environment.NewLine + "Ausgabe aller Postleitzahlen in einer Schleife:");

            foreach (var a in adressen.Elements())
            {
                var anschrift = new XElement(a.Element("Anschrift"));
                Console.WriteLine(anschrift.Element("Postleitzahl").Value);
            }

            // Ausgabe aller Namen per Abfrage:
            Console.WriteLine(Environment.NewLine + "Ausgabe aller Namen per Abfrage:");

            var personen = from p in adressen.Elements()
                           select p.Element("Name").Value;

            foreach (var p in personen)
                Console.WriteLine(p);

            // Ausgabe aller Namen die mit 'A' beginnen
            Console.WriteLine(Environment.NewLine + "Ausgabe aller Namen die mit 'A' beginnen");
            personen = from p in adressen.Elements()
                       where p.Element("Name").Value.StartsWith("A")
                       select p.Element("Name").Value;

            foreach (var p in personen)
                Console.WriteLine(p);

            // Ausgabe aller Straßennamen alphabetisch sortiert
            Console.WriteLine(Environment.NewLine + "Ausgabe aller Straßennamen alphabetisch sortiert:");
            personen = from p in adressen.Elements()
                       orderby p.Element("Anschrift").Element("Straße").Value
                       select p.Element("Anschrift").Element("Straße").Value;

            foreach (var p in personen)
                Console.WriteLine(p);

            Console.Read();
        }
    }
}