﻿using System;
using System.Xml.Linq;

namespace LinqToXML_Step1
{
    class Program
    {
        static void Main()
        {
            var Adressen = new XDocument(
                new XDeclaration("1.0", "UTF-16", "yes"),
                new XComment("Kommentar"),
                new XElement("Adressen",
                             new XElement("Adresse",
                                          new XElement("Name", "Paul Faul"),
                                          new XElement("Telefon", "000"),
                                          new XElement("Anschrift",
                                                       new XElement("Straße", "Musterstraße 1"),
                                                       new XElement("Stadt", "Musterstadt"),
                                                       new XElement("Postleitzahl", "99999")
                                              )
                                 )
                    )
                );

            Adressen.Save("D:\\test.xml");

            Console.Write(Adressen);
            Console.Read();
        }
    }
}
