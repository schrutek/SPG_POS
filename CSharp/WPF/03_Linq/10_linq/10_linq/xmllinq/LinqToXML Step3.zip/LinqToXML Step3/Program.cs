﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace LinqToXML_Step3
{
    class Program
    {
        // globale Variable die das XML enthält
        private static XElement adressen;

        static void Main()
        {
            // private Variablen für den späteren Gebrauch
            var personZumÄndernDerStraße = "Maria Kron";
            var personZumLöschen = "Anna Log";

            // Pfad zum XML File über Refection ermitteln.
            // Die XML Datei muss im gleichen Verzeichnis wie die exe liegen
            var pathXmlFile = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), "Adressen.xml");

            // XML File laden
            adressen = XElement.Load(pathXmlFile);

            // Ändern der Straße einer Person
            Console.WriteLine("{0} wohnt in der {1}", personZumÄndernDerStraße, GetStreetName(personZumÄndernDerStraße));
            Console.WriteLine("> Ändern der Straße von {0}.", personZumÄndernDerStraße);

            ChangeStreetName(personZumÄndernDerStraße, "Hauptstraße 1");
            Console.WriteLine("{0} wohnt jetzt in der {1}{2}", personZumÄndernDerStraße, GetStreetName(personZumÄndernDerStraße), Environment.NewLine);

            // löschen einer Person
            Console.WriteLine("Folgende Personen sind vorhanden:");

            foreach (var s in GetAllPersons())
                Console.WriteLine(s);

            Console.WriteLine("{0}> Löschen der Person {1}.", Environment.NewLine, personZumLöschen);
            DeleteAddress(personZumLöschen);
            Console.WriteLine("Jetzt sind nur noch folgende Personen vorhanden:");

            foreach (var s in GetAllPersons())
                Console.WriteLine(s);

            // Einfügen eines neuen Datensatzes
            Console.WriteLine("{0}> Einfügen eines neuen Datensatzes", Environment.NewLine);
            InsertNewPerson("Paul Faul", "25358754695", "Bismarckstraße", "Hamburg", "20095");
            Console.WriteLine("Folgende Personen sind jetzt vorhanden:");

            foreach (var s in GetAllPersons())
                Console.WriteLine(s);

            Console.WriteLine("{0}> Löschen aller Telefonnummern", Environment.NewLine);
            DeleteAllPhoneNumbers();

            Console.Read();

            // sollen die Änderungen zurück auf Festplatte geschrieben werden, kann dies jederzeit mit der Save Methode gemacht werden
            // adressen.Save(pathXmlFile);
        }

        /// <summary>
        /// Changes the name of the street.
        /// </summary>
        /// <param name="person">The person.</param>
        /// <param name="neueStraße">The neue straße.</param>
        static void ChangeStreetName(string person, string neueStraße)
        {
            var anschrift = (from p in adressen.Elements()
                             where p.Element("Name").Value == person
                             select p).First();

            anschrift.SetElementValue("Straße", neueStraße);
        }

        /// <summary>
        /// Deletes the address.
        /// </summary>
        /// <param name="nameDerPerson">The name der person.</param>
        static void DeleteAddress(string nameDerPerson)
        {
            (from p in adressen.Elements()
             where p.Element("Name").Value == nameDerPerson
             select p).Remove();
        }

        /// <summary>
        /// Inserts the new person.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="telefon">The telefon.</param>
        /// <param name="straße">The straße.</param>
        /// <param name="stadt">The stadt.</param>
        /// <param name="Postleitzahl">The postleitzahl.</param>
        static void InsertNewPerson(string name, string telefon, string straße, string stadt, string Postleitzahl)
        {
            var neuePerson = new XElement("Adresse",
                             new XElement("Name", name),
                             new XElement("Telefon", telefon),
                             new XElement("Anschrift",
                                        new XElement("Straße", straße),
                                        new XElement("Stadt", stadt),
                                        new XElement("Postleitzahl", Postleitzahl)
                               )
                  );
            adressen.Add(neuePerson);
        }

        /// <summary>
        /// Gets the name of the street.
        /// </summary>
        /// <param name="nameDerPerson">The name der person.</param>
        /// <returns></returns>
        static string GetStreetName(string nameDerPerson)
        {
            return (from p in adressen.Elements()
                    where p.Element("Name").Value == nameDerPerson
                    select p.Element("Straße")).First().Value;
        }

        /// <summary>
        /// Gets all persons.
        /// </summary>
        /// <returns></returns>
        static List<string> GetAllPersons()
        {
            return (from p in adressen.Elements()
                    orderby p.Element("Name").Value
                    select p.Element("Name").Value).ToList();
        }

        /// <summary>
        /// Deletes all phone numbers.
        /// </summary>
        static void DeleteAllPhoneNumbers()
        {
            foreach (var telefon in adressen.Descendants("Telefon").ToList())
                telefon.Value = string.Empty;
        }
    }
}